package com.company;

import java.util.HashSet;


public class Person implements Comparable<Person> {


    private String name;
    private String fyllo;
    HashSet<Person>spouse;
    HashSet<Person> parents;
    HashSet<Person> children;

    public Person(String name, String fyllo) {
        this.name = name;
        this.fyllo = fyllo;
        this.spouse = new HashSet<Person>();
        this.parents = new HashSet<Person>();
        this.children = new HashSet<Person>();
    }

    public Person(String name) {
        this.name = name;
        this.parents = new HashSet<Person>();
        this.children = new HashSet<Person>();
        this.spouse = new HashSet<Person>();
    }

    public Person(){
        parents = new HashSet<Person>();
        children = new HashSet<Person>();
        spouse = new HashSet<Person>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFyllo() {
        return fyllo;
    }

    public void setFyllo(String fyllo) {
        this.fyllo = fyllo;
    }

    public String toString() {
        return "Person{" + "name='" + name + ", gender= " + fyllo + '}' + "\n";
    }

    @Override
    public int compareTo(Person o) {
        return name.compareTo(o.getName());
    }

}

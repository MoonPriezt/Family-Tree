package com.company;

import java.io.*;
import java.util.*;

public class ProjectApp {

        static GTree gt;

    public static ArrayList<Person> persons = new ArrayList<Person>();

    public static void runMenu() {
        int choice;
        gt = new GTree();
        Scanner readerIn = new Scanner(System.in);
        do {
            String menu ="===================================================\n"+
                    "Please select a function from the menu below\n" +
                    "1. Load family tree from CSV file\n" +
                    "2. Sort the names and write to file\n" +
                    "3. Find relationship between family members\n" +
                    "4. Print Family Data\n"+
                    "5. Exit\n" +
                    "\nEnter your choice: ";
            System.out.println(menu);
            choice = readerIn.nextInt();
            switch (choice) {
                case 1:
                    loadCSVTree();
                    break;
                case 2:
                    sortNameAndWriteToFile();
                    break;
                case 3:
                    findRelationship();
                    break;
                case 4:
                    printArrayList();
                    break;

            }
        } while (choice != 5);
    }

    public static void loadCSVTree() {
        String line;
        try {
            BufferedReader br = new BufferedReader(new FileReader("tree.csv"));
            try {
                while((line=br.readLine())!= null)
                {
                    processLineFromCSVFile(line);
                }
                br.close();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public static void sortNameAndWriteToFile() {

        File file = new File("tree.csv");
        Set<Person> persons = new TreeSet<>();

        try {
            Scanner input = new Scanner(file);

            while(input.hasNextLine()){
                String line = input.nextLine();
                String[] nameAndGender = line.split(",");
                persons.add(new Person(nameAndGender[0], (nameAndGender[1])));
            }

            input.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


        System.out.println(persons);

    }

   public static void findRelationship() {

       {
           Scanner input = new Scanner(System.in);
           String name1, name2, rel;
           Person p1,p2;
           do
           {
               System.out.print("Enter first name: ");
               name1 = input.nextLine();
               p1 = gt.addPersonAndReturnPerson(name1);
           }while(p1 == null);

           do
           {
               System.out.print("Enter the second name: ");
               name2 = input.nextLine();
               p2 = gt.addPersonAndReturnPerson(name2);
           }while(p2 == null);


           if(gt.checkIfParent(p1, p2))
               System.out.println(p1.getName() +" is the parent of " + p2.getName());

           if(gt.checkIfChild(p1, p2))
               System.out.println(p1.getName() +" is the child of " + p2.getName());

           if (gt.checkifSpouse(p1, p2))
               System.out.println(p1.getName() +" is the spouse of " + p2.getName());
       }

   }
    public static void processLineFromCSVFile(String line)
    {
        String [] data = line.split(",");
        String name1, name2, fyllo, role;

        switch(data.length)
        {
            case 2:
                name1 = data[0].trim();
                fyllo = data[1].trim();
                Person p= gt.addPersonAndReturnPerson(name1);
                p.setFyllo(fyllo);
                break;
            case 3:
                name1 = data[0].trim();
                Person p1= gt.addPersonAndReturnPerson(name1);
                role = data[1].trim();
                name2 = data[2].trim();
                Person p2= gt.addPersonAndReturnPerson(name2);
                gt.addRelationship(p1,role, p2);
                break;
            default:
                System.out.println("Not a valid selection");
        }

    }
    public static void printArrayList(){
        System.out.println(gt.getMyGTree());
    }

}
package com.company;

import java.util.HashMap;

public class GTree {

    private HashMap<String, Person> myGTree;

    public GTree() {
        myGTree = new HashMap<String, Person>();
    }

    public HashMap<String, Person> getMyGTree() {
        return myGTree;
    }

    public void setMyGTree(HashMap<String, Person> myGTree) {
        this.myGTree = myGTree;
    }

    public Person addPersonAndReturnPerson(String name)
    {
        Person p;
        //anazitisi sto hashMap me vasi to onoma
        //An to atomo exei eisaxthei to hashmap tha epistrafei
        //to adikeimneo person
        p = this.myGTree.get(name);
        if(p == null)
        {
            p = new Person(name);
            this.myGTree.put(name, p);
        }
        return p;
    }

    public void addRelationship(Person p1, String rel, Person p2)
    {
        if(rel.equals("spouse"))
        {
            p1.spouse.add(p2);
            p2.spouse.add(p1);
        }

        if(rel.equals("father"))
        {
            p1.children.add(p2);
            p2.parents.add(p1);
        }

        if(rel.equals("mother"))
        {
            p1.children.add(p2);
            p2.parents.add(p1);
        }

    }

    public boolean checkIfParent(Person p1, Person p2)
    {
        return p1.children.contains(p2);
    }

    public boolean checkIfChild(Person p1, Person p2)
    {
        return p1.parents.contains(p2);
    }

    public boolean checkifSpouse(Person p1, Person p2 )
    {
        return p1.spouse.contains(p2);
    }

    /*public boolean checkifSiblings(Person p1, Person p2, String rel)
    {

    }
    */
}
